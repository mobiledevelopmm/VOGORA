
import 'package:flutter/material.dart';

import '../auth/widgets/fashion_background.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  static const Color coral = Color(0xFFFF5E62);
  static const Color berry = Color(0xFF91475B);
  static const Color espresso = Color(0xFF29211F);
  static const Color secondary = Color(0xFF6F625D);

  void _openCollection(
      BuildContext context, {
        required bool isTrending,
      }) {
    Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute(
        builder: (_) => StyleCollectionPage(isTrending: isTrending),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.sizeOf(context).height;
    final double previewHeight =
    (screenHeight * 0.205).clamp(155.0, 185.0).toDouble();

    return FashionBackground(
      overlayOpacity: 0.84,
      child: SafeArea(
        child: SingleChildScrollView(
          // Keep only a small bottom inset. The old 110px padding created
          // an unnecessarily large blank area above the navigation bar.
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'VOGORA',
                        style: TextStyle(
                          fontSize: 23,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 3,
                          color: berry,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        'Hello, Fashion Lover 👋',
                        style: TextStyle(
                          fontSize: 12,
                          color: espresso.withValues(alpha: 0.7),
                        ),
                      ),
                    ],
                  ),
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: const Color(0xFFF1D8D8),
                    child: IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.person_outline_rounded,
                        color: berry,
                        size: 22,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 18),

              // Inspiration Banner
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(19, 17, 19, 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(23),
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFFFFD6C9),
                      Color(0xFFF3B9B2),
                      Color(0xFFE8B6B8),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: berry.withValues(alpha: 0.12),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'YOUR STYLE, YOUR STORY',
                            style: TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.7,
                              color: berry,
                            ),
                          ),
                          const SizedBox(height: 9),
                          const Text(
                            'Discover the Style\nThat Feels Like You.',
                            style: TextStyle(
                              fontSize: 22,
                              height: 1.2,
                              fontWeight: FontWeight.w800,
                              color: espresso,
                            ),
                          ),
                          const SizedBox(height: 7),
                          const Text(
                            'Explore outfits made for your personality.',
                            style: TextStyle(
                              fontSize: 10,
                              color: secondary,
                            ),
                          ),
                          const SizedBox(height: 13),
                          ElevatedButton(
                            onPressed: () => _openCollection(
                              context,
                              isTrending: false,
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: berry,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 15,
                                vertical: 10,
                              ),
                              minimumSize: Size.zero,
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  'Explore My Style',
                                  style: TextStyle(fontSize: 11),
                                ),
                                SizedBox(width: 7),
                                Icon(Icons.arrow_forward_rounded, size: 14),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Icon(
                      Icons.checkroom_rounded,
                      size: 76,
                      color: Color(0x6691475B),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 23),

              // Styled for You
              _sectionHeader(
                title: 'Styled for You',
                subtitle: 'Looks selected for your personal style',
                onSeeAll: () => _openCollection(
                  context,
                  isTrending: false,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: previewHeight,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: const [
                    _PreviewCard(
                      title: 'Casual',
                      subtitle: 'Effortless everyday looks',
                      imageUrl:
                      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=700',
                    ),
                    SizedBox(width: 13),
                    _PreviewCard(
                      title: 'Korean',
                      subtitle: 'Soft & modern fashion',
                      imageUrl:
                      'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=700',
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 22),

              // Trending Styles
              _sectionHeader(
                title: 'Trending Styles',
                subtitle: 'Popular looks and fashion inspiration',
                onSeeAll: () => _openCollection(
                  context,
                  isTrending: true,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: previewHeight,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: const [
                    _PreviewCard(
                      title: 'Streetwear',
                      subtitle: 'Bold and confident looks',
                      imageUrl:
                      'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=700',
                    ),
                    SizedBox(width: 13),
                    _PreviewCard(
                      title: 'Formal',
                      subtitle: 'Elegant and polished outfits',
                      imageUrl:
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=700',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionHeader({
    required String title,
    required String subtitle,
    required VoidCallback onSeeAll,
  }) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: espresso,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: const TextStyle(
                  fontSize: 10,
                  color: secondary,
                ),
              ),
            ],
          ),
        ),
        TextButton(
          onPressed: onSeeAll,
          style: TextButton.styleFrom(
            foregroundColor: coral,
            padding: const EdgeInsets.symmetric(horizontal: 4),
            minimumSize: Size.zero,
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          child: const Row(
            children: [
              Text(
                'See All',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                ),
              ),
              SizedBox(width: 4),
              Icon(Icons.arrow_forward_ios_rounded, size: 11),
            ],
          ),
        ),
      ],
    );
  }
}

// Home Page Preview Card
class _PreviewCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String imageUrl;

  const _PreviewCard({
    required this.title,
    required this.subtitle,
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 190,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.network(
              imageUrl,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: const Color(0xFFF1D8D8),
                child: const Icon(
                  Icons.checkroom_rounded,
                  size: 45,
                  color: HomePage.berry,
                ),
              ),
            ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Color(0xCC29211F),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 14,
              right: 12,
              bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Style Collection Page
class StyleCollectionPage extends StatefulWidget {
  final bool isTrending;

  const StyleCollectionPage({
    super.key,
    required this.isTrending,
  });

  @override
  State<StyleCollectionPage> createState() =>
      _StyleCollectionPageState();
}

class _StyleCollectionPageState extends State<StyleCollectionPage> {
  static const Color coral = Color(0xFFFF5E62);
  static const Color berry = Color(0xFF91475B);
  static const Color espresso = Color(0xFF29211F);

  final List<String> categories = [
    'Casual',
    'Korean',
    'Streetwear',
    'Formal',
    'Sporty',
  ];

  String selectedCategory = 'Casual';

  @override
  void initState() {
    super.initState();
    selectedCategory = widget.isTrending ? 'Streetwear' : 'Casual';
  }

  final Map<String, List<_OutfitItem>> outfits = {
    'Casual': [
      _OutfitItem(
        title: 'Casual Chic',
        description: 'Simple and comfortable everyday outfit',
        imageUrl:
        'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=700',
      ),
      _OutfitItem(
        title: 'Relaxed Look',
        description: 'A relaxed and effortless combination',
        imageUrl:
        'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=700',
      ),
      _OutfitItem(
        title: 'Everyday Fashion',
        description: 'Easy pieces for daily wear',
        imageUrl:
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=700',
      ),
    ],
    'Korean': [
      _OutfitItem(
        title: 'Korean Minimal',
        description: 'Clean and minimal Korean fashion',
        imageUrl:
        'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=700',
      ),
      _OutfitItem(
        title: 'Soft Korean Look',
        description: 'Soft colors and elegant silhouettes',
        imageUrl:
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=700',
      ),
      _OutfitItem(
        title: 'Modern Korean',
        description: 'Modern everyday Korean outfit',
        imageUrl:
        'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=700',
      ),
    ],
    'Streetwear': [
      _OutfitItem(
        title: 'Urban Street',
        description: 'Bold street-inspired outfit',
        imageUrl:
        'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=700',
      ),
      _OutfitItem(
        title: 'Street Chic',
        description: 'Comfortable and confident street style',
        imageUrl:
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=700',
      ),
      _OutfitItem(
        title: 'Modern Street',
        description: 'Modern urban fashion inspiration',
        imageUrl:
        'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=700',
      ),
    ],
    'Formal': [
      _OutfitItem(
        title: 'Elegant Formal',
        description: 'A polished and elegant appearance',
        imageUrl:
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=700',
      ),
      _OutfitItem(
        title: 'Office Chic',
        description: 'Smart and sophisticated outfit',
        imageUrl:
        'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=700',
      ),
      _OutfitItem(
        title: 'Classic Elegance',
        description: 'Timeless formal fashion',
        imageUrl:
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=700',
      ),
    ],
    'Sporty': [
      _OutfitItem(
        title: 'Sporty Casual',
        description: 'Comfortable activewear inspiration',
        imageUrl:
        'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=700',
      ),
      _OutfitItem(
        title: 'Active Look',
        description: 'Easy and energetic sporty style',
        imageUrl:
        'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=700',
      ),
      _OutfitItem(
        title: 'Athleisure',
        description: 'Sporty pieces for everyday wear',
        imageUrl:
        'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=700',
      ),
    ],
  };

  @override
  Widget build(BuildContext context) {
    final currentOutfits = outfits[selectedCategory] ?? [];

    return FashionBackground(
      overlayOpacity: 0.88,
      child: Material(
        color: Colors.transparent,
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // App Bar
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 20, 16),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(
                        Icons.arrow_back_ios_new_rounded,
                        color: berry,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      child: Text(
                        widget.isTrending
                            ? 'Trending Styles'
                            : 'Styled for You',
                        style: const TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.w800,
                          color: espresso,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Description
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  widget.isTrending
                      ? 'Explore popular fashion styles and get inspired.'
                      : 'Discover outfits that match your personal style.',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF6F625D),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Horizontal Category Buttons
              SizedBox(
                height: 43,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  scrollDirection: Axis.horizontal,
                  itemCount: categories.length,
                  separatorBuilder: (_, __) =>
                  const SizedBox(width: 9),
                  itemBuilder: (context, index) {
                    final category = categories[index];
                    final isSelected =
                        selectedCategory == category;

                    return ChoiceChip(
                      label: Text(category),
                      selected: isSelected,
                      showCheckmark: false,
                      onSelected: (_) {
                        setState(() {
                          selectedCategory = category;
                        });
                      },
                      backgroundColor:
                      Colors.white.withValues(alpha: 0.8),
                      selectedColor: berry,
                      labelStyle: TextStyle(
                        color: isSelected
                            ? Colors.white
                            : espresso,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                      side: BorderSide(
                        color: isSelected
                            ? berry
                            : berry.withValues(alpha: 0.15),
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 20),

              // Selected Category Title
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Text(
                      selectedCategory,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: espresso,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: coral.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        '${currentOutfits.length} Looks',
                        style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: berry,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 14),

              // Outfit Grid
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 25),
                  itemCount: currentOutfits.length,
                  gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 14,
                    mainAxisSpacing: 16,
                    childAspectRatio: 0.66,
                  ),
                  itemBuilder: (context, index) {
                    final outfit = currentOutfits[index];

                    return _OutfitGridCard(item: outfit);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Outfit Data Model
class _OutfitItem {
  final String title;
  final String description;
  final String imageUrl;

  const _OutfitItem({
    required this.title,
    required this.description,
    required this.imageUrl,
  });
}

// Outfit Grid Card
class _OutfitGridCard extends StatelessWidget {
  final _OutfitItem item;

  const _OutfitGridCard({
    required this.item,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(17),
            child: Image.network(
              item.imageUrl,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: const Color(0xFFF1D8D8),
                width: double.infinity,
                child: const Icon(
                  Icons.checkroom_rounded,
                  size: 45,
                  color: HomePage.berry,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          item.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: HomePage.espresso,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          item.description,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontSize: 10,
            color: HomePage.secondary,
          ),
        ),
      ],
    );
  }
}