import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../data/services/auth_service.dart';
import 'auth_state.dart';

class AuthCubit extends Cubit<AuthState> {
  final AuthService _authService;

  late final StreamSubscription<User?> _authSubscription;

  AuthCubit(this._authService) : super(const AuthState()) {
    _authSubscription = _authService.authStateChanges.listen(
      _onAuthChanged,
      onError: (_) {
        if (!isClosed) {
          emit(const AuthState(
            status: AuthStatus.error,
            errorMessage: 'Unable to check authentication status.',
          ));
        }
      },
    );
  }

  // Listen to Firebase Authentication changes
  void _onAuthChanged(User? user) {
    if (isClosed) return;

    if (user != null) {
      emit(AuthState(
        status: AuthStatus.authenticated,
        userName: user.displayName,
        userEmail: user.email,
      ));
    } else {
      emit(const AuthState(
        status: AuthStatus.unauthenticated,
      ));
    }
  }

  // Register
  Future<void> register({
    required String name,
    required String email,
    required String password,
  }) async {
    emit(state.copyWith(
      status: AuthStatus.loading,
      clearError: true,
    ));

    try {
      await _authService.register(
        name: name,
        email: email,
        password: password,
      );

      final user = _authService.currentUser;

      emit(AuthState(
        status: AuthStatus.authenticated,
        userName: user?.displayName ?? name,
        userEmail: user?.email ?? email,
      ));
    } on FirebaseAuthException catch (e) {
      emit(AuthState(
        status: AuthStatus.error,
        errorMessage: _getErrorMessage(e.code),
      ));
    } catch (_) {
      emit(const AuthState(
        status: AuthStatus.error,
        errorMessage: 'Something went wrong. Please try again.',
      ));
    }
  }

  // Login
  Future<void> login({
    required String email,
    required String password,
  }) async {
    emit(state.copyWith(
      status: AuthStatus.loading,
      clearError: true,
    ));

    try {
      await _authService.login(
        email: email,
        password: password,
      );

      final user = _authService.currentUser;

      emit(AuthState(
        status: AuthStatus.authenticated,
        userName: user?.displayName,
        userEmail: user?.email ?? email,
      ));
    } on FirebaseAuthException catch (e) {
      emit(AuthState(
        status: AuthStatus.error,
        errorMessage: _getErrorMessage(e.code),
      ));
    } catch (_) {
      emit(const AuthState(
        status: AuthStatus.error,
        errorMessage: 'Something went wrong. Please try again.',
      ));
    }
  }

  // Logout
  Future<void> logout() async {
    emit(state.copyWith(
      status: AuthStatus.loading,
      clearError: true,
    ));

    try {
      await _authService.logout();

      emit(const AuthState(
        status: AuthStatus.unauthenticated,
      ));
    } catch (_) {
      emit(const AuthState(
        status: AuthStatus.error,
        errorMessage: 'Unable to log out. Please try again.',
      ));
    }
  }

  // Firebase error messages
  String _getErrorMessage(String code) {
    switch (code) {
      case 'email-already-in-use':
        return 'This email is already registered.';

      case 'invalid-email':
        return 'Please enter a valid email address.';

      case 'weak-password':
        return 'Password is too weak. Use at least 6 characters.';

      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'Incorrect email or password.';

      case 'user-disabled':
        return 'This account has been disabled.';

      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';

      case 'network-request-failed':
        return 'Please check your internet connection.';

      default:
        return 'Authentication failed. Please try again.';
    }
  }

  @override
  Future<void> close() {
    _authSubscription.cancel();
    return super.close();
  }
}
