part of 'body_measurements_cubit.dart';

@freezed
class BodyMeasurementsState with _$BodyMeasurementsState {
  const factory BodyMeasurementsState.initial() = _Initial;
}
