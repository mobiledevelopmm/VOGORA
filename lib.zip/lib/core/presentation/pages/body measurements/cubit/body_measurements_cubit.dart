import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'body_measurements_state.dart';
part 'body_measurements_cubit.freezed.dart';

class BodyMeasurementsCubit extends Cubit<BodyMeasurementsState> {
  BodyMeasurementsCubit() : super(const BodyMeasurementsState.initial());
}
